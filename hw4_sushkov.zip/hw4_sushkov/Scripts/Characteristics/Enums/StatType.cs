﻿namespace LabyrinthGame.Stats
{
    public enum StatType
    {
        Undefined = 0,
        Health = 1,
        Speed = 3,
        JumpPower = 4
    }
}