﻿namespace LabyrinthGame.Stats
{
    public interface IHaveStats
    {
        StatHolder StatHolder { get; }
    }
}