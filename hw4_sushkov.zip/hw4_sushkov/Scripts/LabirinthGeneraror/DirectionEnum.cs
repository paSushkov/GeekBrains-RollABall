﻿namespace LabyrinthGame.LevelGenerator
{
    public enum Direction
    {
        Up,
        Down,
        Left,
        Right,
        None
    }
}
