﻿namespace LabyrinthGame.Effects
{
    public class ExtraValue
    {
        public readonly float value;

        public ExtraValue(float value)
        {
            this.value = value;
        }
    }
}