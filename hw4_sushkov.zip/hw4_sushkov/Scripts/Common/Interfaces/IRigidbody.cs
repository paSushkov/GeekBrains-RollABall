﻿using UnityEngine;

namespace LabyrinthGame.Common.Interfaces
{
    public interface IRigidbody
    {
        Rigidbody ModelRigidbody { get;}
    }
}