﻿namespace LabyrinthGame.Common.Handlers
{
    public delegate void AxisInputHandler(float axisInput);
}