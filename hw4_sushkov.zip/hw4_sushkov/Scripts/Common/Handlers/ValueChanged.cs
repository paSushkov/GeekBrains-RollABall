﻿namespace LabyrinthGame.Common.Handlers
{
    public delegate void ValueChanged(float newValue);
}