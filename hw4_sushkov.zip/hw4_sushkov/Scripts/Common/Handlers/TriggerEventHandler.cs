﻿using UnityEngine;

namespace LabyrinthGame.Common.Handlers
{
public delegate void TriggerEventHandler (Collider other);
}
