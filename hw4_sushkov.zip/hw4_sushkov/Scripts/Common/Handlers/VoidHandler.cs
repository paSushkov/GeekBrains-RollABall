﻿namespace LabyrinthGame.Common.Handlers
{
    public delegate void VoidHandler();
}