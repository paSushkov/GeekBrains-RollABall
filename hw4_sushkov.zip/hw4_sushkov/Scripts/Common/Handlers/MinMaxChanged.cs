﻿namespace LabyrinthGame.Common.Handlers
{
    public delegate void MinMaxChanged(float newMinValue, float newMaxValue);
}