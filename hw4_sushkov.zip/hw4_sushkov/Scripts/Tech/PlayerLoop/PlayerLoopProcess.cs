﻿namespace LabyrinthGame.Tech.PlayerLoop
{
    public delegate void PlayerLoopProcess(float deltaTime);
}