﻿namespace LabyrinthGame.Tech.Input
{
    
    public delegate void InputControllerChanged(IInputController newController);
}